const { func } = require("assert-plus");

function q1() {
    let array2D = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ];

    console.log("Element at the second row and third column:", array2D[1][2]);
    array2D[1][2] = 10;

    console.log("Modified 2D array:");
    for (let row of array2D) {
        console.log(row);
    }
}

function q2() {
    let array2D = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ];

    console.log("2D Array:");
    for (let i = 0; i < array2D.length; i++) {
        for (let j = 0; j < array2D[i].length; j++) {
            console.log("Element at (" + i + ", " + j + "):", array2D[i][j]);
        }
}

function q3() {
    let seatingChart = [
        ["Andrew", "Bobby", "Chee", "Donald"],
        ["Eve", "Frank", "Grace", "Harry"],
        ["Ivy", "Jack", "Kong", "Lim"],
        ["Mohan", "Neil", "Olivia", "Peter"],
        ["Quinn", "Rose", "Sammy", "Trump"]
    ];
    seatingChart[2][2] = "Sammy"; // Change Kong seat to Sammy

    console.log("Updated Seating Chart:");
    for (let i = 0; i < seatingChart.length; i++) {
        for (let j = 0; j < seatingChart[i].length; j++) {
            console.log("Seat at (" + i + ", " + j + "):", seatingChart[i][j]);
            }
        }
    }
}

function q4() {
    let array2D = [
        [1, 2, 3],
        [4, 5, 6],
        [7, 8, 9]
    ];
    let sum = 0;
    for (let i = 0; i < array2D.length; i++) {
        for (let j = 0; j < array2D[i].length; j++) {
            sum += array2D[i][j];
        }
    }
    console.log("Sum of all elements:", sum);
}

function q5(arr) {
    const n = arr.length;
    for (let i = 0; i < n; i++) {
        console.log(arr[i][i]);
    }
}

function q6(arr) {
    for (let row of arr) {
        let largestInRow = row[0];
        for (let num of row) {
            if (num > largestInRow) {
                largestInRow = num;
            }
        }
        console.log("Largest number in row:", largestInRow);
    }
}

function q7() {
    function updateInventoryQuantity(inventory, productName, newQuantity) {
        for (let product of inventory) {
            if (product[0] === productName) {
                product[2] = newQuantity;
                return;
            }
        }
        console.log("Product not found in inventory.");
    }

    function printInventory(inventory) {
        console.log("Product Inventory:");
        for (let product of inventory) {
            console.log(product.join("\t"));
        }
    }

    const inventory = [
        ["Apple", "$0.10", 5],
        ["Pear", "$0.20", 8],
        ["Durian", "$0.80", 3]
    ];

    console.log("Initial Inventory:");
    printInventory(inventory);

    updateInventoryQuantity(inventory, "Pear", 10);

    console.log("\nUpdated Inventory:");
    printInventory(inventory);
}

function q8() {
    // Traditional function syntax IIFE
    (function() {
        console.log("Hello, World");
    })();

    // Arrow function syntax IIFE
    (() => {
        console.log("Hello, World");
    })();
}

function q9() {
    ((num1, num2) => {
        console.log("Sum of", num1, "and", num2, "is:", num1 + num2);
    })(5, 7);
}

function q10() {
    const add = (a, b) => a + b; 
}

function q11() {
    const square = num => num * num;
}

function q12() {
    const mohan = () => "Hello, World!";
}
