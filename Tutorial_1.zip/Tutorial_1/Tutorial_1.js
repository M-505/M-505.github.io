function q1() {
    let a = 53;
    let b = 3.14;
    let c = "Hello, world!";
    let d = true; 

    console.log("Value of a:", a, "Type of a:", typeof a);
    console.log("Value of b:", b, "Type of b:", typeof b);
    console.log("Value of c:", c, "Type of c:", typeof c);
    console.log("Value of d:", d, "Type of d:", typeof d);

}

function q2() {
    let age = 25;
    let gst = 0.09; 
    let isRaining = false; 
    let username = "Samantha Brown";


    console.log(age);
    console.log(gst);
    console.log(isRaining);
    console.log(username);
}

function q3() {
    let num1 = 10;
    let num2 = 5;
    let sum = num1 + num2;
    let difference = num1 - num2;
    let multiply = num1 * num2;
    let division = num1 / num2;

    console.log("Sum:", sum);
    console.log("Difference:", difference);
    console.log("multiply:", multiply);
    console.log("division:", division);
}

function q4(num1, num2) {
    let sum = num1 + num2;
    console.log("Sum:", sum);
    let difference = num1 - num2;
    console.log("Difference:", difference);
    let Multiplication = num1 * num2;
    console.log("Multiplication:", Multiplication);
    let Division = num1 / num2;
    console.log("Division:", Division);
    }

    let num1 = parseFloat(prompt("Enter the first number:"));
    let num2 = parseFloat(prompt("Enter the second number:"));

    q4();

function q5() {
    let cost = 1.50; 
    let numberOfDonuts = 20; 
    let total = cost * numberOfDonuts;
    console.log("Total cost:", total.toFixed(2));
}

function q6() {
    let taxRate = 0.029;
    let income = 450000; 
    let totalPayment = taxRate * income;
    console.log("Total tax payment:", totalPayment.toFixed(2)); 

}

function q7() {
    let length = 10; 
    let width = 5; 
    let area = length * width;
    console.log("Area of the rectangle:", area);
}

function q8() {
    let d = 2; 
    let c = 50;
    let n = 3; 
    
    let total = d + c / 100;
    total *= n;
    console.log("Total cost:", total.toFixed(2));

}

function q9() {
    const prompt = require('prompt-sync')();
    let firstNumber = prompt("Enter the first number: ");
    let secondNumber = prompt("Enter the second number: ");
    let product = parseFloat(firstNumber) * parseFloat(secondNumber);
    console.log(product);
}

function q10() {
    const prompt = require('prompt-sync')();
    let birthYear = prompt("Enter your birth year: ");
    let currentYear = prompt("Enter the current year: ");
    let age = parseInt(currentYear) - parseInt(birthYear);
    console.log("Your age is:", age);
}

function q11() {
    const prompt = require('prompt-sync')();
    let radius = parseFloat(prompt("Enter the radius of the circle: "));
    const pi = 3.14;
    let area = pi * Math.pow(radius, 2);
    let roundedArea = area.toFixed(2);
    console.log("The area of the circle is:", roundedArea);
}

function q12() {
    const prompt = require('prompt-sync')();
    let num1 = parseFloat(prompt("Enter the first number: "));
    let num2 = parseFloat(prompt("Enter the second number: "));
    let num3 = parseFloat(prompt("Enter the third number: "));
    let num4 = parseFloat(prompt("Enter the fourth number: "));
    let sum = num1 + num2 + num3 + num4;
    let average = sum / 4;
    console.log("The average of the four numbers is:", average);
}

function q13() {
    let a = 5;
    let b = 10;

    a = a + b;
    b = a - b;
    a = a - b;

    console.log("After swapping:");
    console.log("a = ", a);
    console.log("b = ", b);
}

function q14() {
    let celsius = 25;
    let f = (celsius * 9/5) + 32;
    console.log("Temperature in Fahrenheit:", f);

}

function q15() {
    let number = -1;

    if (number > 0) {
        console.log("The number is positive.");
    } else if (number < 0) {
        console.log("The number is negative.");
    } else {
        console.log("The number is zero.");
    }
}

function q16() {
    let num = 7;
    if (num % 2 === 0) {
        console.log("The number is even.");
    } else {
        console.log("The number is odd.");
    }
}

function q17() {
    let score = 85;
    switch (true) {
        case score >= 90 && score <= 100:
            console.log("Grade: A");
            break;
        case score >= 80 && score <= 89:
            console.log("Grade: B");
            break;
        case score >= 70 && score <= 79:
            console.log("Grade: C");
            break;
        case score >= 60 && score <= 69:
            console.log("Grade: D");
            break;
        default:
            console.log("Grade: F");
        }
}

function q18() {
    let isSunny = false;
    let isCloudy = true;
    let isEveGoing = true;
    let isTuesday = false;
    let isJaniceGoing = false;

    if ((isSunny || isCloudy) && isEveGoing && !isTuesday && !isJaniceGoing) {
        console.log("Going to the beach!");
    } else {
        console.log("Not going to the beach!");
    }
}

function q19() {
        let joHeight = 180;
        let joAge = 30;

        let friendHeight = 175;
        let friendAge = 35;

        let joScore = joHeight + (5 * joAge);
        let friendScore = friendHeight + (5 * friendAge);

        console.log("Jo's score:", joScore);
        console.log("Friend's score:", friendScore);

        if (joScore > friendScore) {
            console.log("Jo wins with a score of", joScore);
        } else if (friendScore > joScore) {
            console.log("Friend wins with a score of", friendScore);
        } else {
            console.log("It's a draw!");
        }

        let thirdPlayerHeight = 170;
        let thirdPlayerAge = 25;

        let thirdPlayerScore = thirdPlayerHeight + (5 * thirdPlayerAge);

        console.log("Third player's score:", thirdPlayerScore);

        if (joScore > friendScore && joScore > thirdPlayerScore) {
            console.log("Jo wins with a score of", joScore);
        } else if (friendScore > joScore && friendScore > thirdPlayerScore) {
            console.log("Friend wins with a score of", friendScore);
        } else if (thirdPlayerScore > joScore && thirdPlayerScore > friendScore) {
            console.log("Third player wins with a score of", thirdPlayerScore);
        } else {
            console.log("It's a draw!");
        }
}

function q20() {
    const prompt = require('prompt-sync')();
    let psi = parseFloat(prompt("PSI: "));

        // Check the PSI level and print the corresponding message
        if (psi >= 100) {
            console.log("Unhealthy");
        } else if (psi > 50 && psi < 100) {
            console.log("Moderate");
        } else {
            console.log("Healthy");
        }
}

function q21() {
    const prompt = require('prompt-sync')();
    let X = parseFloat(prompt("Enter the dollars part of the muffin cost (X): "));
    let Y = parseFloat(prompt("Enter the cents part of the muffin cost (Y): "));
    let Z = parseInt(prompt("Enter the number of muffins to buy (Z): "));

    // Calculate total cost in cents
    let totalCents = (X * 100 + Y) * Z;
    let dollars = Math.floor(totalCents / 100);
    let cents = totalCents % 100;

    console.log(`Total cost of ${Z} muffins is $${dollars} and ${cents} cents ($${dollars}.${cents < 10 ? '0' + cents : cents})`);

}

function q22() {
    let x = 3;
    let y = 8;
    let firstName = "Charlie";
    let raining = false;
    let snowing = false;
    let windy = true;

    if (x + y >= 10) {
        console.log("Good!");
    }
    if (x - y < 0) {
        console.log("Good!");
    }
    if (firstName.length >= 11) {
        console.log("Good!");
    }
    if (y - x > 5) {
        console.log("Good!");
    }
    if (x != 10) {
        console.log("Good!");
    }
    if (raining == false) {
        console.log("Good!");
    }
}