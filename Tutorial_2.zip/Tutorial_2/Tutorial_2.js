// Tutorial_2

function q1() {
    for (let i = 1; i <= 100; i++) {
        console.log(i);
    }    
}

function q2() {
    for (let i = 10; i >= 1; i--) {
        console.log(i);
    }
    
    console.log("Liftoff!");    
}

function q3() {
    const prompt = require('prompt-sync')();
    let number;

    do {
        number = parseInt(prompt("Enter a number between 1 and 10: "));
    } while ((number) || number < 1 || number > 10);

    console.log("You entered:", number);
}

function q4() {
    let principal = parseFloat(prompt("Enter the principal amount: "));
    let rate = parseFloat(prompt("Enter the annual interest rate (in percentage): "));
    let time = 0;
    let totalAmount = principal;

    const doubledAmount = principal * 2;

    while (totalAmount < doubledAmount) {
        totalAmount += (principal * rate) / 100;
        time++;
    }

    console.log(`It took ${time} years for the total amount to double.`);

}

function q5() {
    for (let i = 2; i <= 20; i += 2) {
        console.log(i);
    }    
}

//q5();

function q6() {
    const prompt = require('prompt-sync')();
    const correctNumber = 7;
    let guess;

do {
    guess = parseInt(prompt("Guess the number (between 1 and 10): "));
    if (guess === correctNumber) {
        console.log("Congratulations! You guessed the correct number.");
    } else {
        console.log("Sorry, that's not the correct number. Try again.");
    }
    } while (guess !== correctNumber)
}

function q7() {
    const prompt = require('prompt-sync')();
    for (;;) {
        let input = prompt("Enter a word type 'exit' to quit: ");
        if (input.toLowerCase() === "exit") {
            console.log("Exiting the loop...");
            break;
        }
    }
}

function q8() {
    for (let i = 1; i <= 5; i++) {
        let row = '';
        for (let j = 1; j <= i; j++) {
            row += '* ';
        }
        console.log(row);
    }    
}

function q9(arr) {
    let sum = 0;
    for (let i = 0; i < arr.length; i++) {
        sum += arr[i];
    }
    return sum;
    }
    let numbers = [1, 2, 3, 4, 5];
    console.log("Sum of array:", q9(numbers));

function q10(arr) {
    let max = arr[0];
    for (let i = 1; i < arr.length; i++) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }

    return max;
}

let numbers2 = [5, 8, 2, 10, 3];
console.log("Maximum number:", q10(numbers2));

function q11(arr) {
    let reversed = '';
    for (let i = str.length - 1; i >= 0; i--) {
        reversed += str[i];
    }
    return reversed;
}

let originalString = "Hello, Malcom !";
console.log("Reversed string:", reverseString(originalString));

function q12() {
    let number = 8;
    console.log(`Multiplication table for ${number}:`);
    for (let i = 1; i <= 10; i++) {
        console.log(`${number} * ${i} = ${number * i}`);
    }
}

function q13() {
    let fruits = ["apple", "banana", "orange", "durian"];
    for (let fruit of fruits) {
        console.log(fruit);
    }
}

function q14() {
    let i = 1;
    let j = 1;
    while (i <= 5) {
        console.log(i * j);
        i++; 
        j++;
    }
}