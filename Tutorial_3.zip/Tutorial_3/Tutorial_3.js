function q1() {
    let fruits = ["apple", "banana", "orange"];
    fruits.push("mango");
    fruits.unshift("strawberry");
    console.log(fruits);
}

function q2() {
    let fruits = ["strawberry", "apple", "banana", "orange", "mango"];
    let removedLast = fruits.pop();
    let removedFirst = fruits.shift();
    console.log("Modified array:", fruits);
    console.log("Removed last element:", removedLast);
    console.log("Removed first element:", removedFirst);
}

function q3(arr) {
    let reversed = [];
    for (let i = arr.length - 1; i >= 0; i--) {
        reversed.push(arr[i]);
    }
    return reversed;
}

function q4() {
    console.log(8 == "8"); // true 
    console.log(8 === "8"); // false 
}

function q5(width, height) {
    return width * height;

}

function q6() { 
    function checkAge(age) {
        if (age < 13) {
            return "child";
        } else if (age >= 13 && age < 20) {
            return "teen";
        } else {
            return "adult";
        }
    }

    console.log("Age 8 is a", checkAge(8));
    console.log("Age 15 is a", checkAge(15));
    console.log("Age 30 is a", checkAge(30));
}

function q7() {
    function celsiusToFahrenheit(celsius) {
        return (celsius * 9/5) + 32;
    }

    console.log("0°C in Fahrenheit:", celsiusToFahrenheit(0));
    console.log("10°C in Fahrenheit:", celsiusToFahrenheit(10));
    console.log("20°C in Fahrenheit:", celsiusToFahrenheit(20));
    console.log("30°C in Fahrenheit:", celsiusToFahrenheit(30));
}

function q8() {
    function calculateInterest(principal, rate, time) {
        let interest = (principal * rate * time) / 100;
        return interest;
    }
    let principal = 1000;
    let rate = 5;
    let time = 2;
    let interest = calculateInterest(principal, rate, time);
    console.log("Simple interest:", interest);  
}

function q9() {

    function isOddOrEven(number) {
        if (number % 2 === 0) {
            return "Even";
        } else {
            return "Odd";
        }
    }
    console.log("Is 3 odd or even?", isOddOrEven(3));
    console.log("Is 10 odd or even?", isOddOrEven(10));
    console.log("Is 25 odd or even?", isOddOrEven(25));
}

function q10() {
    function calculator(operand1, operand2, operator) {
        let result;
        switch (operator) {
            case "+":
                result = operand1 + operand2;
                break;
            case "-":
                result = operand1 - operand2;
                break;
            case "*":
                result = operand1 * operand2;
                break;
            case "/":
                result = operand1 / operand2;
                break;
            default:
                return "Invalid operator";
        }
        return result;
    }
}

function q11() {
    function minutesToSeconds(minutes) {
        return minutes * 60;
    }
    console.log("5 minutes is equal to", minutesToSeconds(5), "seconds");
    console.log("10 minutes is equal to", minutesToSeconds(10), "seconds");
    console.log("15 minutes is equal to", minutesToSeconds(15), "seconds");
}

function q12() {
    function printTable(number) {
        for (let i = 1; i <= 10; i++) {
            console.log(number + " × " + i + " = " + (number * i));
        }
    }
    printTable(5);
}

function q13() {
    function printTable(number) {
        for (let i = 1; i <= 10; i++) {
            console.log(number + " × " + i + " = " + (number * i));
        }
    }
    function calculateCircleArea(radius) {
        const pi = 3.14159;
        return pi * radius ** 2;
    }
    printTable(5);
    let radius = 3;
    console.log("The area of the circle with radius", radius, "is", calculateCircleArea(radius));
}

function q14() {
    function canVote(age) {
        return age >= 21;
    }
}

function q15() {
    function findLargest(num1, num2) {
        return num1 > num2 ? num1 : num2;
    }
    console.log("Largest between 10 and 5:", findLargest(10, 5));
    console.log("Largest between -3 and 8:", findLargest(-3, 8));
    console.log("Largest between 12 and 12:", findLargest(12, 12));
}

function q16() {
    function addNumbers(a, b) {
        var sum = Number(a) + Number(b); // use Number to Convert the String to Number..
        console.log(sum);
    }
    addNumbers(10, '20'); 
}
