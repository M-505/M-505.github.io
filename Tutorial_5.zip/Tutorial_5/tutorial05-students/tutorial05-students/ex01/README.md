# Create a simple recipe HTML page
In this activity, you will start to make your own recipe. You will be introduced to five common HTML tags; headings, paragraphs, image, ordered lists and unordered lists. 
