# Instructions  
This is a simple exercise to get you going with CSS. Try it out and get some creative juice flowing.

## Steps
1. Use the existing external CSS file “style.css”
2. Add the css file using the <link> method
3. Add a few CSS properties (color, background-color, font-family, text-align) to the content created in the last activity
4. Try messing around a little more :) 