document.addEventListener('DOMContentLoaded', function () {
    let hotItems = document.querySelectorAll('li.hot');
    for (let i = 0; i < hotItems.length; i++) {
        hotItems[i].className = 'cool';
    }

    let hotItems2 = document.getElementsByClassName('hot');
    if (hotItems2.length >= 3) {
        hotItems2[2].className = 'cool';
    }
    let hotItems3 = document.getElementsByTagName('li');
    for (let i = 0; i < hotItems3.length; i++) {
        if (hotItems3[i].className === 'hot') {
            hotItems3[i].className = 'cool';
            break;
        }
    }
});
