# Taskmaster
Solve the following questions and place them in the javascript file

**Learning Objective**: Cycle through nodelists and manipulate nodes accordingly

- Write code using a **loop** to select only the elements with the class `li.hot` and change all the class attributes of the elements to `cool`.

- Write code using the `getElementsByClassName()` function and check if there are 3 or more elements found with the class attribute of `hot`. Run through the nodelist retrieved using a loop and use a if statement to check. Then change only the 3rd element class attribute to `cool`.

- Write code using the `getElementsByTagName()` function and check if there are at least one list item `li` found with the class attribute of `hot`. Then change only the 1st element class attribute to “cool”.
