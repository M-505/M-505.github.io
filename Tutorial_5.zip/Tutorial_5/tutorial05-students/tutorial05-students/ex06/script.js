document.addEventListener('DOMContentLoaded', function () {
    let box1Element = document.querySelector("#box1");
    let box2Element = document.querySelector("#box2");
    let calculateBtn = document.querySelector("#calculateBtn");

    calculateBtn.addEventListener('click', function () {
        let value1 = parseFloat(box1Element.value);
        let value2 = parseFloat(box2Element.value);
        let sum = value1 + value2;
        alert("The sum is: " + sum);

    });
});
