let text;
let words;
let characters;